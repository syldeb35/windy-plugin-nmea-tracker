#!/bin/bash
chmod +x gps_server.py
./gps_server.py
