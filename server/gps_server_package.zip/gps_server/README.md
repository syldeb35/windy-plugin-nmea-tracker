
# GPS Server UDP to HTTPS

## Compilation

### Linux

```bash
chmod +x build_linux.sh
./build_linux.sh
./dist/gps_server
```

### Windows

Dans Git Bash ou WSL :

```bash
./build_win.sh
./dist/gps_server.exe
```

## Test

Visitez : `https://localhost:5000/gps-data`
