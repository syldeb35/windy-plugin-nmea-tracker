
#!/usr/bin/env python3
from flask import Flask, Response
import threading
import socket
from flask_cors import CORS
import os
import sys

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except AttributeError:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

app = Flask(__name__)
CORS(app)

latest_nmea = "$GPGLL,,,,,,V"
UDP_IP = "0.0.0.0"
UDP_PORT = 5005

def udp_listener():
    global latest_nmea
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((UDP_IP, UDP_PORT))
    print(f"[UDP] Listening on {UDP_IP}:{UDP_PORT}")
    while True:
        data, addr = sock.recvfrom(1024)
        message = data.decode('utf-8', errors='ignore').strip()
        print(f"[UDP] Received from {addr}: {message}")
        if message.startswith("$GNGLL") or message.startswith("$GPGLL"):
            latest_nmea = message
        if message.startswith("$GNGGA") or message.startswith("$GPGGA"):
            latest_nmea = latest_nmea + "\r\n" + message
        if message.startswith("$GNRMC") or message.startswith("$GPRMC"):
            latest_nmea = latest_nmea + "\r\n" + message

@app.route('/gps-data')
def gps_data():
    return Response(latest_nmea, mimetype='text/plain')

if __name__ == '__main__':
    udp_thread = threading.Thread(target=udp_listener, daemon=True)
    udp_thread.start()

    cert_path = resource_path("cert.pem")
    key_path = resource_path("key.pem")
    app.run(host='0.0.0.0', port=5000, ssl_context=(cert_path, key_path))
