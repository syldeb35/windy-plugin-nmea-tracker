
#!/bin/bash
pip install pyinstaller
pyinstaller --onefile --add-data "cert.pem:." --add-data "key.pem:." gps_server.py
